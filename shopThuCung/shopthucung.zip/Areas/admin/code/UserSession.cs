﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shopthucung.Areas.admin.code
{
    [Serializable]
    public class UserSession
    {
        public string UserName { set; get; }
    }
}